/**
 * Use dayjs to parse cell contents for sorting
 */
export declare const parseDate: (content: string, format: string) => string | number;
