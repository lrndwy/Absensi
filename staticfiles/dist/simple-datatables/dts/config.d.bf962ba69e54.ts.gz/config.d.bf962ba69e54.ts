import { DataTableConfiguration } from "./types";
/**
 * Default configuration
 */
export declare const defaultConfig: DataTableConfiguration;
