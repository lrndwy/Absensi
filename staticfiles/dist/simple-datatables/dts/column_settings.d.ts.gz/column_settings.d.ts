import { columnsStateType, columnSettingsType } from "./types";
export declare const readColumnSettings: (columnOptions: any[], defaultType: any, defaultFormat: any) => [columnSettingsType[], columnsStateType];
