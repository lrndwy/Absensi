import { elementNodeType } from "./types";
export declare const createVirtualPagerDOM: (onFirstPage: boolean, onLastPage: boolean, currentPage: number, totalPages: number, options: any) => elementNodeType;
